//
//  FileTest.swift
//  GMLGame
//
//  Created by guominglong on 16/1/15.
//  Copyright © 2016年 guominglong. All rights reserved.
//

import Foundation
public class FileTest:NSObject{
    //private var zip:Zip
    private var zip:ZipArchive!;
    public override init() {
        super.init();
        ginit();
    }
    
    private func ginit()
    {
       // zip = ZipArchive();
        
    }
    
    private func jieyasuo(path:String)
    {
        //zip.UnzipOpenFile(path);
        //zip.UnzipFileTo(<#T##path: String!##String!#>, overWrite: <#T##Bool#>)
    }
}