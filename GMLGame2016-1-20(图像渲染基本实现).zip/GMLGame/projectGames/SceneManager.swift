//  场景管理器
//  SceneManager.swift
//  GMLGame
//
//  Created by guominglong on 16/1/18.
//  Copyright © 2016年 guominglong. All rights reserved.
//

import Foundation
public class SceneManager:GMLObject{
    public override init()
    {
        super.init();
        
    }
}